window.onload = function(){
      
document.getElementById("btn").addEventListener("click", clicked);
document.getElementById("dnl").addEventListener("click", download);
      
function clicked(){
        
 document.getElementById("dd").innerHTML = Date() ;
 
  
}
     

     
     
     function download(){
       
       window.open = "dateView/dateViewSrc.zip";
       
     }
     
      
      
 }
    
    
    
  